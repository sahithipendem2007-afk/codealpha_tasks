// ===== Data (replace placeholder links with your real URLs) =====
const skills = [
  { name: "HTML5", level: 90, text: "Semantic and accessible web structure." },
  { name: "CSS3", level: 85, text: "Responsive layouts, animations and modern styling." },
  { name: "JavaScript", level: 75, text: "Interactive web functionality and DOM logic." },
  { name: "Responsive Design", level: 85, text: "Fluid grids, flexbox and mobile-first breakpoints." },
  { name: "Git", level: 70, text: "Version control for everyday project work." },
  { name: "GitHub", level: 70, text: "Repositories, branches and Pages hosting." },
  { name: "UI/UX Basics", level: 65, text: "Hierarchy, spacing and usability fundamentals." },
];

const projects = [
  {
    title: "Image Gallery",
    image: "assets/project-gallery.jpg",
    tags: ["HTML", "CSS", "JavaScript"],
    categories: ["Frontend", "JavaScript"],
    description: "Responsive image gallery featuring category filters, lightbox viewing and interactive navigation.",
    github: "https://github.com/your-username/image-gallery",
    demo: "https://your-username.github.io/image-gallery",
  },
  {
    title: "Smart Calculator",
    image: "assets/project-calculator.jpg",
    tags: ["HTML", "CSS", "JavaScript"],
    categories: ["Frontend", "JavaScript"],
    description: "Keyboard-friendly calculator with chained operations, clear error handling and a glass interface.",
    github: "https://github.com/your-username/smart-calculator",
    demo: "https://your-username.github.io/smart-calculator",
  },
  {
    title: "Personal Portfolio",
    image: "assets/project-portfolio.jpg",
    tags: ["HTML", "CSS", "Responsive"],
    categories: ["Frontend", "HTML/CSS"],
    description: "This portfolio: a fully responsive single-page site with smooth scrolling, scroll reveals and hover effects.",
    github: "https://github.com/your-username/portfolio",
    demo: "https://your-username.github.io/portfolio",
  },
];

const CONTACT_EMAIL = "your.email@example.com";

// ===== Render skills & projects =====
document.getElementById("skillsGrid").innerHTML = skills
  .map(
    (s) => `
    <article class="skill glass reveal">
      <div class="skill-top"><h3>${s.name}</h3><span>${s.level}%</span></div>
      <p>${s.text}</p>
      <div class="bar"><i style="--level:${s.level}%"></i></div>
    </article>`
  )
  .join("");

document.getElementById("projectsGrid").innerHTML = projects
  .map(
    (p) => `
    <article class="project glass reveal" data-categories="${p.categories.join(",")}">
      <div class="thumb"><img src="${p.image}" alt="${p.title} preview" loading="lazy" /></div>
      <div class="project-body">
        <h3>${p.title}</h3>
        <span class="tags">${p.tags.join(" • ")}</span>
        <p>${p.description}</p>
        <div class="project-btns">
          <a class="btn btn-glass" href="${p.github}" target="_blank" rel="noreferrer">GitHub</a>
          <a class="btn btn-primary" href="${p.demo}" target="_blank" rel="noreferrer">Live Demo</a>
        </div>
      </div>
    </article>`
  )
  .join("");

// ===== Navbar: scroll state, mobile menu, active link =====
const nav = document.getElementById("nav");
const hamburger = document.getElementById("hamburger");
const navLinks = document.getElementById("navLinks");
const links = document.querySelectorAll(".nav-link");

window.addEventListener("scroll", () => nav.classList.toggle("scrolled", window.scrollY > 24), { passive: true });

hamburger.addEventListener("click", () => {
  const open = navLinks.classList.toggle("open");
  hamburger.classList.toggle("open", open);
  hamburger.setAttribute("aria-expanded", String(open));
  hamburger.setAttribute("aria-label", open ? "Close menu" : "Open menu");
});

links.forEach((link) =>
  link.addEventListener("click", () => {
    navLinks.classList.remove("open");
    hamburger.classList.remove("open");
    hamburger.setAttribute("aria-expanded", "false");
  })
);

const sectionObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        links.forEach((l) => l.classList.toggle("active", l.getAttribute("href") === `#${entry.target.id}`));
      }
    });
  },
  { rootMargin: "-40% 0px -55% 0px" }
);
document.querySelectorAll("main section").forEach((s) => sectionObserver.observe(s));

// ===== Scroll reveal =====
const revealObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        revealObserver.unobserve(entry.target);
      }
    });
  },
  { threshold: 0.12 }
);
document.querySelectorAll(".reveal").forEach((el) => revealObserver.observe(el));

// ===== Project filter =====
document.querySelectorAll(".filter").forEach((btn) =>
  btn.addEventListener("click", () => {
    document.querySelectorAll(".filter").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    const f = btn.dataset.filter;
    document.querySelectorAll(".project").forEach((card) => {
      const show = f === "All" || card.dataset.categories.split(",").includes(f);
      card.classList.toggle("hide", !show);
      if (show) card.classList.add("visible");
    });
  })
);

// ===== Contact form validation (mailto, no backend) =====
const form = document.getElementById("contactForm");
const note = document.getElementById("formNote");

function setError(id, msg) {
  document.getElementById(id).classList.toggle("invalid", Boolean(msg));
  form.querySelector(`.err[data-for="${id}"]`).textContent = msg;
}

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const message = document.getElementById("message").value.trim();
  let ok = true;

  if (!name) { setError("name", "Please tell me your name."); ok = false; } else setError("name", "");
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { setError("email", "Please enter a valid email address."); ok = false; } else setError("email", "");
  if (!message) { setError("message", "Please write a message."); ok = false; } else setError("message", "");

  if (!ok) return;

  const subject = encodeURIComponent(`Portfolio message from ${name}`);
  const body = encodeURIComponent(`${message}\n\n— ${name} (${email})`);
  note.textContent = "Thanks! Your email app should now open with the message ready to send.";
  note.classList.add("ok");
  window.location.href = `mailto:${CONTACT_EMAIL}?subject=${subject}&body=${body}`;
});
